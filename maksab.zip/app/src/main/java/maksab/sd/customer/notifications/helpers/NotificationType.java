package maksab.sd.customer.notifications.helpers;

public enum NotificationType {
    NOT_USED, CHAT, ORDER_UPDATE, ACCOUNT_UPDATE,
    QUOTATION_UPDATE, TRANSACTION, NEW_QUOTATION
}