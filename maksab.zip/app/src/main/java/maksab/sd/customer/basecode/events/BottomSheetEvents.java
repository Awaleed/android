package maksab.sd.customer.basecode.events;

public interface BottomSheetEvents {
    void onAddService(int position , int quantity);
    void onAddService();
}
