package maksab.sd.customer.util.general;

/**
 * Created by AdminUser on 11/12/2017.
 */

public class NetWorkCheck {

    public static boolean IsNetWorkAvilable(){

        return true;
    }
}
