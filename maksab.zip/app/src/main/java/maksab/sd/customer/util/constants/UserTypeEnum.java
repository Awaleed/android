package maksab.sd.customer.util.constants;

public enum UserTypeEnum {
    ZERO_NOT_USED, Customer, Provider, Support
}
