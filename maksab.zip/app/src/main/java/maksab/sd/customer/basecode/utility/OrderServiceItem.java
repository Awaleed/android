package maksab.sd.customer.basecode.utility;

public class OrderServiceItem {
    public int serviceId;
    public int serviceQuntity;
    public OrderServiceItem(int serviceId, int serviceQuntity) {
        this.serviceId = serviceId;
        this.serviceQuntity = serviceQuntity;
    }


}
