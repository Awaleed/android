package maksab.sd.customer.util.constants;

public  class SettingLabels {
    public static int VERSION = 0;
    public static int ORDER = 1;
    public static int BALANCE = 2;
    public static int PROFILE = 3;
    public static int TERMS = 4;
    public static int SUPPORT = 5;
        public static int SHARE = 6;
        public static int LOGOUT = 7;
        public static int Address = 8;

}
