package maksab.sd.customer.basecode.events;

public interface OnSelectTime {
    void onTimeSelected(int position);
}
