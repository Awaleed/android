package maksab.sd.customer.util.constants;

public enum MessagesTypesEnums {
    ZERO_NOT_USED,
    Text, Image, Voice, Location, Video, Document
}
