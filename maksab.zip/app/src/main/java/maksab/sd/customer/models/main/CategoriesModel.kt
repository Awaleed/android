package maksab.sd.customer.models.main

/**
 * Created by AdminUser on 10/27/2017.
 */

data class CategoriesModel(val id: Int ,val arabicName: String  ,val englishName: String , val image: String, val description: String) {
}
