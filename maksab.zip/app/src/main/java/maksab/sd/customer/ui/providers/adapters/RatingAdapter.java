package maksab.sd.customer.ui.providers.adapters;

/**
 * Created by Dev on 2/24/2018.
 */

public class RatingAdapter {
}
