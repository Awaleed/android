package maksab.sd.customer.ui.profile.broadcasts;

/**
 * Created by dev2 on 1/28/2018.
 */

public interface SmsListener {

    public void messageReceived(String messageText);
}
