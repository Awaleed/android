package maksab.sd.customer.util.constants;

/**
 * Created by AdminUser on 11/12/2017.
 */

public class ClintTypeConstaent {
    public static final String PROVIDER = "Provider";
    public static final String CUSTOMER = "customer";
}
