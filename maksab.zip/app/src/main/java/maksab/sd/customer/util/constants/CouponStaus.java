package maksab.sd.customer.util.constants;

/**
 * Created by AdminUser on 02/07/2018.
 */

public class CouponStaus {
    public static final int Active = 1;
    public static final int Used = 2;
    public static final int Exprired = 3;
    public static final int Invalid = 4;
}
