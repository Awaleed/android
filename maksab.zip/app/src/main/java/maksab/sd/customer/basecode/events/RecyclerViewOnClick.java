package maksab.sd.customer.basecode.events;

public interface RecyclerViewOnClick {
    void onClicked(int position);
}
