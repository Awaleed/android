package maksab.sd.customer.util.constants;

public enum CategoriesStatusTypeEnum {
    Active , Soon , Disabled
}
