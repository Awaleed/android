package maksab.sd.customer.basecode.events;

public interface OnSelectDay {
    void onDaySelected(int position);
}
