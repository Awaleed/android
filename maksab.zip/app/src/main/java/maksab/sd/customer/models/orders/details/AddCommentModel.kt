package maksab.sd.customer.models.orders.details

data class AddCommentModel(var isMedia : Boolean , var body : String) {
}