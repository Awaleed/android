package maksab.sd.customer.basecode.utility;

public enum OrderChatMessageTypeEnum {
    NotSpecified,Offer,Location,Invoice,LeftText,RightText , LeftImage , RightImage
}
