package maksab.sd.customer.util.general;

public  class AddressInMemoryStorage {
    public static String body = "";
    public static String district = "";
    public static int id;
}
