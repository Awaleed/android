package maksab.sd.customer.basecode.utility;

public enum QuestionControlTypes {
    FreeText, SingleChoice, MultipleChoice, GPS, Image, FreeTextLong , STARS
}
