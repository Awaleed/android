package maksab.sd.customer.util.constants;

public enum NotificationsCategoriesTypesEnum {
    Unkown, // Old Notifiication will be here (most will be action based and manullay and remainder)
    Action, Reminder, Manually, // For Specific User
    BroadCast, Competition     // All Topic without users
}
