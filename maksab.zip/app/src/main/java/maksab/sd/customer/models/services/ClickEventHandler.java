package maksab.sd.customer.models.services;

public interface ClickEventHandler {

    void handleClick(int id);
}
